package UniLink;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;

/**
 * This class manages the view and operations of enrollment records in a GUI application.
 * It includes features to edit, delete, refresh, and export enrollment records.
 */
public class viewRecordsEnrollment extends JFrame {
    private JTable tableEnrollments;
    private JButton buttonEdit;
    private JButton buttonDelete;
    private JButton buttonRefresh;
    private JButton buttonBackToMenu;
    private JButton buttonExport;  // New Export button

    public viewRecordsEnrollment() {
        // Set up the JFrame properties
        setTitle("Enrollment Records");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize components
        tableEnrollments = new JTable();
        buttonEdit = new JButton("Edit");
        buttonDelete = new JButton("Delete");
        buttonRefresh = new JButton("Refresh");
        buttonBackToMenu = new JButton("Back to Menu");
        buttonExport = new JButton("Export");  // Initialize Export button

        // Create a main panel with BorderLayout
        JPanel panel = new JPanel(new BorderLayout());

        // Add the table with scroll functionality
        panel.add(new JScrollPane(tableEnrollments), BorderLayout.CENTER);

        // Create panels for left and right button groups
        JPanel panelLeftButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        JPanel panelRightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JPanel panelButtons = new JPanel(new BorderLayout());

        // Add buttons to the left panel
        panelLeftButtons.add(buttonEdit);
        panelLeftButtons.add(buttonDelete);
        panelLeftButtons.add(buttonRefresh);

        // Add buttons to the right panel
        panelRightButtons.add(buttonBackToMenu);
        panelRightButtons.add(buttonExport);

        // Add left and right button panels to the main button panel
        panelButtons.add(panelLeftButtons, BorderLayout.WEST);
        panelButtons.add(panelRightButtons, BorderLayout.EAST);

        // Add the button panel to the south of the main panel
        panel.add(panelButtons, BorderLayout.SOUTH);

        // Add the main panel to the JFrame
        getContentPane().add(panel);

        // Set action listeners for the buttons
        buttonEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editSelectedEnrollment();
            }
        });
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteSelectedEnrollment();
            }
        });

        buttonRefresh.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshEnrollmentTable();
            }
        });

        buttonBackToMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToMenu();
            }
        });

        buttonExport.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                exportTableData();
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);

                if (confirmed == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        // Load the table data
        refreshEnrollmentTable();
    }

    /**
     * Edits the selected enrollment record.
     */
    private void editSelectedEnrollment() {
        int selectedRow = tableEnrollments.getSelectedRow();
        if (selectedRow != -1) {
            // Retrieve the EnrollmentID value from the selected row
            int enrollmentID = (Integer) tableEnrollments.getValueAt(selectedRow, 0);

            // Fetch current data for the selected enrollment
            String query = "SELECT * FROM tbl_enrollment WHERE EnrollmentID = ?";
            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setInt(1, enrollmentID);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    // Create a form to edit the enrollment's details
                    JTextField txtStudentID = new JTextField(resultSet.getString("StudentID"));
                    JTextField txtCourseID = new JTextField(resultSet.getString("CourseID"));
                    JDateChooser calenEnrollmentDate = new JDateChooser(resultSet.getDate("EnrollmentDate"));

                    JPanel panel = new JPanel(new GridLayout(4, 2));
                    panel.add(new JLabel("Student ID:"));
                    panel.add(txtStudentID);
                    panel.add(new JLabel("Course ID:"));
                    panel.add(txtCourseID);
                    panel.add(new JLabel("Enrollment Date:"));
                    panel.add(calenEnrollmentDate);

                    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Enrollment", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        // Update enrollment details
                        String updateQuery = "UPDATE tbl_enrollment SET StudentID = ?, CourseID = ?, EnrollmentDate = ? WHERE EnrollmentID = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setString(1, txtStudentID.getText());
                            updateStatement.setString(2, txtCourseID.getText());
                            updateStatement.setDate(3, new java.sql.Date(calenEnrollmentDate.getDate().getTime()));
                            updateStatement.setInt(4, enrollmentID);

                            int rowsAffected = updateStatement.executeUpdate();
                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(this, "Enrollment details updated successfully!");
                                refreshEnrollmentTable();
                            } else {
                                JOptionPane.showMessageDialog(this, "Failed to update enrollment details. No rows affected.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No data found for the selected enrollment.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No enrollment selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deletes the selected enrollment record.
     */
    private void deleteSelectedEnrollment() {
        int selectedRow = tableEnrollments.getSelectedRow();
        if (selectedRow != -1) {
            // Get EnrollmentID from the selected row
            int enrollmentID = (Integer) tableEnrollments.getValueAt(selectedRow, 0);

            // Confirm deletion
            int confirmed = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this enrollment?",
                    "Delete Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (confirmed == JOptionPane.YES_OPTION) {
                // SQL query to delete the enrollment record
                String query = "DELETE FROM tbl_enrollment WHERE EnrollmentID = ?";

                try (Connection connection = getConnection();
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the EnrollmentID parameter
                    preparedStatement.setInt(1, enrollmentID);

                    // Execute the update
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        // Notify the user of success
                        JOptionPane.showMessageDialog(this,
                                "Enrollment deleted successfully!");

                        // Refresh the table data
                        refreshEnrollmentTable();
                    } else {
                        // Notify the user if no rows were affected
                        JOptionPane.showMessageDialog(this,
                                "Failed to delete enrollment. No rows affected.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    // Handle SQL exceptions
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                            "Database error: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            // Notify the user if no row is selected
            JOptionPane.showMessageDialog(this,
                    "No enrollment selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Refreshes the enrollment table with the latest data from the database.
     */
    private void refreshEnrollmentTable() {
        String query = "SELECT EnrollmentID, StudentID, CourseID, EnrollmentDate FROM tbl_enrollment";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            tableEnrollments.setModel(TableModelBuilder.buildTableModel(resultSet));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Exports the table data to a CSV file.
     */
    private void exportTableData() {
        // Create a file chooser for saving the CSV file
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export to CSV");
        
        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            // Attempt to write table data to the selected file
            try (FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() + ".csv")) {
                DefaultTableModel model = (DefaultTableModel) tableEnrollments.getModel();

                // Write column headers
                for (int i = 0; i < model.getColumnCount(); i++) {
                    fileWriter.write(model.getColumnName(i) + ",");
                }
                fileWriter.write("\n");

                // Write rows data
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        fileWriter.write(model.getValueAt(i, j).toString() + ",");
                    }
                    fileWriter.write("\n");
                }

                // Notify the user of successful export
                JOptionPane.showMessageDialog(this, "Data exported successfully!");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error exporting data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Establishes a connection to the database.
     * 
     * @return A Connection object to the database
     * @throws SQLException If an error occurs while connecting
     */
    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/unilink_db";
        String user = "root";
        String password = "nics1108";
        return DriverManager.getConnection(url, user, password);
    }

    /**
     * Navigates back to the main menu.
     */
    private void backToMenu() {
        // Implement your back to menu logic here
        new dashboard().setVisible(true); // Assuming dashboard is another JFrame for the main menu
        this.dispose();
    }

    /**
     * Main method to run the application.
     * 
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new viewRecordsEnrollment().setVisible(true);
            }
        });
    }
}

