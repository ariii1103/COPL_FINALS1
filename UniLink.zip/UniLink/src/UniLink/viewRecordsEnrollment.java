package UniLink;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;

public class viewRecordsEnrollment extends JFrame {
    private JTable tableEnrollments;
    private JButton buttonEdit;
    private JButton buttonDelete;
    private JButton buttonRefresh;
    private JButton buttonBackToMenu;

    public viewRecordsEnrollment() {
        setTitle("Enrollment Records");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        tableEnrollments = new JTable();
        buttonEdit = new JButton("Edit");
        buttonDelete = new JButton("Delete");
        buttonRefresh = new JButton("Refresh");
        buttonBackToMenu = new JButton("Back to Menu");

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableEnrollments), BorderLayout.CENTER);

        JPanel panelButtons = new JPanel();
        panelButtons.add(buttonEdit);
        panelButtons.add(buttonDelete);
        panelButtons.add(buttonRefresh);
        panelButtons.add(buttonBackToMenu);

        panel.add(panelButtons, BorderLayout.SOUTH);

        getContentPane().add(panel);

        buttonEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                editSelectedEnrollment();
            }
        });
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteSelectedEnrollment();
            }
        });

        buttonRefresh.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                refreshEnrollmentTable();
            }
        });

        buttonBackToMenu.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                backToMenu();
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);

                if (confirmed == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        refreshEnrollmentTable();
    }

    private void editSelectedEnrollment() {
        int selectedRow = tableEnrollments.getSelectedRow();
        if (selectedRow != -1) {
            // Retrieve the EnrollmentID value from the selected row
            int enrollmentID = (Integer) tableEnrollments.getValueAt(selectedRow, 0);

            // Fetch current data for the selected enrollment
            String query = "SELECT * FROM tbl_enrollment WHERE EnrollmentID = ?";
            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setInt(1, enrollmentID);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    // Create a form to edit the enrollment's details
                    JTextField txtStudentID = new JTextField(resultSet.getString("StudentID"));
                    JTextField txtCourseID = new JTextField(resultSet.getString("CourseID"));
                    JDateChooser calenEnrollmentDate = new JDateChooser(resultSet.getDate("EnrollmentDate"));

                    JPanel panel = new JPanel(new GridLayout(4, 2));
                    panel.add(new JLabel("Student ID:"));
                    panel.add(txtStudentID);
                    panel.add(new JLabel("Course ID:"));
                    panel.add(txtCourseID);
                    panel.add(new JLabel("Enrollment Date:"));
                    panel.add(calenEnrollmentDate);

                    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Enrollment", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        // Update enrollment details
                        String updateQuery = "UPDATE tbl_enrollment SET StudentID = ?, CourseID = ?, EnrollmentDate = ? WHERE EnrollmentID = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setString(1, txtStudentID.getText());
                            updateStatement.setString(2, txtCourseID.getText());
                            updateStatement.setDate(3, new java.sql.Date(calenEnrollmentDate.getDate().getTime()));
                            updateStatement.setInt(4, enrollmentID);

                            int rowsAffected = updateStatement.executeUpdate();
                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(this, "Enrollment details updated successfully!");
                                refreshEnrollmentTable();
                            } else {
                                JOptionPane.showMessageDialog(this, "Failed to update enrollment details. No rows affected.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No data found for the selected enrollment.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No enrollment selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedEnrollment() {
        int selectedRow = tableEnrollments.getSelectedRow();
        if (selectedRow != -1) {
            // Get EnrollmentID from the selected row
            int enrollmentID = (Integer) tableEnrollments.getValueAt(selectedRow, 0);

            // Confirm deletion
            int confirmed = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this enrollment?",
                    "Delete Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (confirmed == JOptionPane.YES_OPTION) {
                // SQL query to delete the enrollment record
                String query = "DELETE FROM tbl_enrollment WHERE EnrollmentID = ?";

                try (Connection connection = getConnection();
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the EnrollmentID parameter
                    preparedStatement.setInt(1, enrollmentID);

                    // Execute the update
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        // Notify the user of success
                        JOptionPane.showMessageDialog(this,
                                "Enrollment deleted successfully!");

                        // Refresh the table data
                        refreshEnrollmentTable();
                    } else {
                        // Notify the user if no rows were affected
                        JOptionPane.showMessageDialog(this,
                                "Failed to delete enrollment. No rows affected.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    // Handle SQL exceptions
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                            "Database error: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            // Notify the user if no row is selected
            JOptionPane.showMessageDialog(this,
                    "No enrollment selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshEnrollmentTable() {
        String query = "SELECT EnrollmentID, StudentID, CourseID, EnrollmentDate FROM tbl_enrollment";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            tableEnrollments.setModel(TableModelBuilder.buildTableModel(resultSet));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/unilink_db";
        String user = "root";
        String password = "nics1108";
        return DriverManager.getConnection(url, user, password);
    }

    private void backToMenu() {
        // Implement your back to menu logic here
        new dashboard().setVisible(true); // Assuming dashboard is another JFrame for the main menu
        this.dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new viewRecordsEnrollment().setVisible(true);
            }
        });
    }
}