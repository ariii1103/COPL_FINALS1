/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UniLink;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel; 
import java.awt.*;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.event.WindowAdapter; 
import java.awt.event.WindowEvent; 
import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author gogua
 */
public class viewRecordsStudent extends JFrame {
    private JTable tableUsers;
    private JButton buttonEdit; 
    private JButton buttonDelete; 
    private JButton buttonRefresh; 
    private JButton buttonBackToMenu;
    
    public viewRecordsStudent() {
        setTitle("Student Records"); 
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 
        setLocationRelativeTo(null);

        tableUsers = new JTable();
        buttonEdit = new JButton("Edit"); 
        buttonDelete = new JButton("Delete"); 
        buttonRefresh = new JButton("Refresh"); 
        buttonBackToMenu = new JButton("Back to Menu");

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableUsers), BorderLayout.CENTER);

        JPanel panelButtons = new JPanel(); 
        panelButtons.add(buttonEdit); 
        panelButtons.add(buttonDelete); 
        panelButtons.add(buttonRefresh); 
        panelButtons.add(buttonBackToMenu);

        panel.add(panelButtons, BorderLayout.SOUTH);
        
        getContentPane().add(panel); 
        
        buttonEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                editSelectedUser();
            }
        });
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                deleteSelectedUser();
            }
        });

        buttonRefresh.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                refreshUserTable();
            }
        });
        
        buttonBackToMenu.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                backToMenu();
            }
        });
        
        addWindowListener(new WindowAdapter() { 
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);

                if (confirmed == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        refreshUserTable();
    }
    
    private void editSelectedUser() {
    int selectedRow = tableUsers.getSelectedRow();
    if (selectedRow != -1) {
        // Retrieve the StudentID value from the selected row as a String
        String studentID = (String) tableUsers.getValueAt(selectedRow, 0);

        // Fetch current data for the selected student
        String query = "SELECT * FROM tbl_student WHERE StudentID = ?";
        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, studentID);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Create a form to edit the student's details
                JTextField txtFirstName = new JTextField(resultSet.getString("FirstName"));
                JTextField txtLastName = new JTextField(resultSet.getString("LastName"));
                JTextField txtEmail = new JTextField(resultSet.getString("Email"));
                JTextField txtPhone = new JTextField(resultSet.getString("Phone"));

                // Create a JComboBox for Gender
                String[] genders = {"Male", "Female", "Other"};
                JComboBox<String> cmbGender = new JComboBox<>(genders);
                cmbGender.setSelectedItem(resultSet.getString("Gender"));

                JDateChooser dateChooser = new JDateChooser(resultSet.getDate("DateOfBirth"));

                JPanel panel = new JPanel(new GridLayout(6, 2));
                panel.add(new JLabel("First Name:"));
                panel.add(txtFirstName);
                panel.add(new JLabel("Last Name:"));
                panel.add(txtLastName);
                panel.add(new JLabel("Email:"));
                panel.add(txtEmail);
                panel.add(new JLabel("Phone:"));
                panel.add(txtPhone);
                panel.add(new JLabel("Gender:"));
                panel.add(cmbGender);
                panel.add(new JLabel("Date of Birth:"));
                panel.add(dateChooser);

                int result = JOptionPane.showConfirmDialog(this, panel, "Edit Student", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    // Update student details
                    String updateQuery = "UPDATE tbl_student SET FirstName = ?, LastName = ?, Email = ?, Phone = ?, Gender = ?, DateOfBirth = ? WHERE StudentID = ?";
                    try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                        updateStatement.setString(1, txtFirstName.getText());
                        updateStatement.setString(2, txtLastName.getText());
                        updateStatement.setString(3, txtEmail.getText());
                        updateStatement.setString(4, txtPhone.getText());
                        updateStatement.setString(5, (String) cmbGender.getSelectedItem());
                        updateStatement.setDate(6, new java.sql.Date(dateChooser.getDate().getTime()));
                        updateStatement.setString(7, studentID);

                        int rowsAffected = updateStatement.executeUpdate();
                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(this, "Student details updated successfully!");
                            refreshUserTable();
                        } else {
                            JOptionPane.showMessageDialog(this, "Failed to update student details. No rows affected.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "No data found for the selected student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "No student selected.", "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private void deleteSelectedUser() {
    int selectedRow = tableUsers.getSelectedRow();
    if (selectedRow != -1) {
        // Get StudentID from the selected row as a String
        String studentID = (String) tableUsers.getValueAt(selectedRow, 0);

        // Confirm deletion
        int confirmed = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this student?",
                "Delete Confirmation",
                JOptionPane.YES_NO_OPTION);

        if (confirmed == JOptionPane.YES_OPTION) {
            // SQL query to delete the student record
            String query = "DELETE FROM tbl_student WHERE StudentID = ?";

            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                // Set the StudentID parameter
                preparedStatement.setString(1, studentID);

                // Execute the update
                int rowsAffected = preparedStatement.executeUpdate();
                
                if (rowsAffected > 0) {
                    // Notify the user of success
                    JOptionPane.showMessageDialog(this,
                            "Student deleted successfully!");

                    // Refresh the table data
                    refreshUserTable();
                } else {
                    // Notify the user if no rows were affected
                    JOptionPane.showMessageDialog(this,
                            "Failed to delete student. No rows affected.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                // Handle SQL exceptions
                e.printStackTrace();
                JOptionPane.showMessageDialog(this,
                        "Database error: " + e.getMessage(),
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    } else {
        // Notify the user if no row is selected
        JOptionPane.showMessageDialog(this,
                "No student selected.",
                "Error",
                JOptionPane.ERROR_MESSAGE);
    }
}

    // Method to get the current logged-in user's ID based on USERNAME.
    // You will need to implement this method to return the ID of the currently logged-in user. 
    private int getCurrentUserId() {
        int userId = -1;
        String query = "SELECT id FROM tbl_student WHERE username = ?";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) { 
            
            preparedStatement.setString(1, login.USERNAME);
            
            try (ResultSet resultSet = preparedStatement.executeQuery()) { 
                if (resultSet.next()) {
                    userId = resultSet.getInt("id");
                }
            }
        } catch (SQLException e) { 
            e.printStackTrace();
        }
        return userId;
    }

    private void refreshUserTable() {
        String query = "SELECT StudentID, LastName, FirstName, Gender, DateOfBirth, Email, Phone FROM tbl_student";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query); 
             ResultSet resultSet = preparedStatement.executeQuery()) {

            tableUsers.setModel(TableModelBuilder.buildTableModel(resultSet));

        } catch (SQLException e) { 
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException { 
        String url = "jdbc:mysql://localhost:3306/unilink_db";
        String user = "root"; 
        String password = "nics1108";
        return DriverManager.getConnection(url, user, password);
    }

    private void backToMenu() {
        // Implement your back to menu logic here
        // For example, you can open a new JFrame for the main menu and dispose this one
        new dashboard().setVisible(true); // Assuming dashboard is another JFrame for the main menu 
        this.dispose();
    }

    public static void main(String[] args) { 
        SwingUtilities.invokeLater(new Runnable() {
            @Override 
            public void run() {
                new viewRecordsStudent().setVisible(true);
            }
        });
    }
}
