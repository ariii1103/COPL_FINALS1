/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package UniLink;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel; 
import java.awt.*;
import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.awt.event.WindowAdapter; 
import java.awt.event.WindowEvent; 
import java.sql.Connection;
import java.sql.DriverManager; 
import java.sql.PreparedStatement; 
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author gogua
 */
public class viewRecordsCourse extends JFrame {
    private JTable tableCourses;
    private JButton buttonEdit; 
    private JButton buttonDelete; 
    private JButton buttonRefresh; 
    private JButton buttonBackToMenu;
    
    public viewRecordsCourse() {
        setTitle("Course Records"); 
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE); 
        setLocationRelativeTo(null);

        tableCourses = new JTable();
        buttonEdit = new JButton("Edit"); 
        buttonDelete = new JButton("Delete"); 
        buttonRefresh = new JButton("Refresh"); 
        buttonBackToMenu = new JButton("Back to Menu");

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableCourses), BorderLayout.CENTER);

        JPanel panelButtons = new JPanel(); 
        panelButtons.add(buttonEdit); 
        panelButtons.add(buttonDelete); 
        panelButtons.add(buttonRefresh); 
        panelButtons.add(buttonBackToMenu);

        panel.add(panelButtons, BorderLayout.SOUTH);
        
        getContentPane().add(panel); 
        
        buttonEdit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                editSelectedCourse();
            }
        });
        buttonDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) { 
                deleteSelectedCourse();
            }
        });

        buttonRefresh.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                refreshCourseTable();
            }
        });
        
        buttonBackToMenu.addActionListener(new ActionListener() { 
            @Override
            public void actionPerformed(ActionEvent e) { 
                backToMenu();
            }
        });
        
        addWindowListener(new WindowAdapter() { 
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);

                if (confirmed == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        refreshCourseTable();
    }
    
    private void editSelectedCourse() {
        int selectedRow = tableCourses.getSelectedRow();
        if (selectedRow != -1) {
            // Retrieve the CourseID value from the selected row as a String
            String courseID = (String) tableCourses.getValueAt(selectedRow, 0);

            // Fetch current data for the selected course
            String query = "SELECT * FROM tbl_course WHERE CourseID = ?";
            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setString(1, courseID);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    // Create a form to edit the course's details
                    JTextField txtCourseName = new JTextField(resultSet.getString("CourseName"));
                    JTextField txtDescription = new JTextField(resultSet.getString("Description"));
                    JTextField txtUnits = new JTextField(resultSet.getString("Units"));

                    JPanel panel = new JPanel(new GridLayout(4, 2));
                    panel.add(new JLabel("Course Name:"));
                    panel.add(txtCourseName);
                    panel.add(new JLabel("Description:"));
                    panel.add(txtDescription);
                    panel.add(new JLabel("Units:"));
                    panel.add(txtUnits);

                    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Course", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        // Parse units from text to float
                        float units;
                        try {
                            units = Float.parseFloat(txtUnits.getText());
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(this, "Please enter a valid number for units.");
                            return; // Exit if the input is not valid
                        }

                        // Update course details
                        String updateQuery = "UPDATE tbl_course SET CourseName = ?, Description = ?, Units = ? WHERE CourseID = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setString(1, txtCourseName.getText());
                            updateStatement.setString(2, txtDescription.getText());
                            updateStatement.setFloat(3, units);
                            updateStatement.setString(4, courseID);

                            int rowsAffected = updateStatement.executeUpdate();
                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(this, "Course details updated successfully!");
                                refreshCourseTable();
                            } else {
                                JOptionPane.showMessageDialog(this, "Failed to update course details. No rows affected.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No data found for the selected course.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No course selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedCourse() {
        int selectedRow = tableCourses.getSelectedRow();
        if (selectedRow != -1) {
            // Get CourseID from the selected row as a String
            String courseID = (String) tableCourses.getValueAt(selectedRow, 0);

            // Confirm deletion
            int confirmed = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this course?",
                    "Delete Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (confirmed == JOptionPane.YES_OPTION) {
                // SQL query to delete the course record
                String query = "DELETE FROM tbl_course WHERE CourseID = ?";

                try (Connection connection = getConnection();
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the CourseID parameter
                    preparedStatement.setString(1, courseID);

                    // Execute the update
                    int rowsAffected = preparedStatement.executeUpdate();
                    
                    if (rowsAffected > 0) {
                        // Notify the user of success
                        JOptionPane.showMessageDialog(this,
                                "Course deleted successfully!");

                        // Refresh the table data
                        refreshCourseTable();
                    } else {
                        // Notify the user if no rows were affected
                        JOptionPane.showMessageDialog(this,
                                "Failed to delete course. No rows affected.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    // Handle SQL exceptions
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                            "Database error: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            // Notify the user if no row is selected
            JOptionPane.showMessageDialog(this,
                    "No course selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void refreshCourseTable() {
        String query = "SELECT CourseID, CourseName, Description, Units FROM tbl_course";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query); 
             ResultSet resultSet = preparedStatement.executeQuery()) {

            tableCourses.setModel(TableModelBuilder.buildTableModel(resultSet));

        } catch (SQLException e) { 
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Connection getConnection() throws SQLException { 
        String url = "jdbc:mysql://localhost:3306/unilink_db";
        String user = "root"; 
        String password = "nics1108";
        return DriverManager.getConnection(url, user, password);
    }

    private void backToMenu() {
        // Implement your back to menu logic here
        // For example, you can open a new JFrame for the main menu and dispose this one
        new dashboard().setVisible(true); // Assuming dashboard is another JFrame for the main menu 
        this.dispose();
    }

    public static void main(String[] args) { 
        SwingUtilities.invokeLater(new Runnable() {
            @Override 
            public void run() {
                new viewRecordsCourse().setVisible(true);
            }
        });
    }
}
