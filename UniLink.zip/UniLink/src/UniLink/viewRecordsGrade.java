package UniLink;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.io.FileWriter;
import java.io.IOException;

/**
 * This class represents the Grade Records management window.
 * It allows users to view, edit, delete, refresh, export, and navigate the grade records.
 */
public class viewRecordsGrade extends JFrame {
    private JTable tableGrades;
    private JButton buttonEdit;
    private JButton buttonDelete;
    private JButton buttonRefresh;
    private JButton buttonBackToMenu;
    private JButton buttonExport;

    /**
     * Constructs the viewRecordsGrade window.
     */
    public viewRecordsGrade() {
        setTitle("Grade Records");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        setLocationRelativeTo(null);

        // Initialize components
        tableGrades = new JTable();
        buttonEdit = new JButton("Edit");
        buttonDelete = new JButton("Delete");
        buttonRefresh = new JButton("Refresh");
        buttonBackToMenu = new JButton("Back to Menu");
        buttonExport = new JButton("Export");

        // Setup main panel with BorderLayout
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JScrollPane(tableGrades), BorderLayout.CENTER);

        // Separate button panels for better organization
        JPanel panelLeftButtons = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panelLeftButtons.add(buttonEdit);
        panelLeftButtons.add(buttonDelete);
        panelLeftButtons.add(buttonRefresh);

        JPanel panelRightButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelRightButtons.add(buttonBackToMenu);
        panelRightButtons.add(buttonExport);

        // Container for buttons
        JPanel panelButtons = new JPanel(new BorderLayout());
        panelButtons.add(panelLeftButtons, BorderLayout.WEST);
        panelButtons.add(panelRightButtons, BorderLayout.EAST);

        panel.add(panelButtons, BorderLayout.SOUTH);
        getContentPane().add(panel);

        // Add action listeners
        buttonEdit.addActionListener(e -> editSelectedGrade());
        buttonDelete.addActionListener(e -> deleteSelectedGrade());
        buttonRefresh.addActionListener(e -> refreshGradeTable());
        buttonBackToMenu.addActionListener(e -> backToMenu());
        buttonExport.addActionListener(e -> exportTableData());

        // Confirm exit dialog
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                int confirmed = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);
                if (confirmed == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });

        // Populate the table with data
        refreshGradeTable();
    }

    /**
     * Edits the selected grade record.
     */
    private void editSelectedGrade() {
        int selectedRow = tableGrades.getSelectedRow();
        if (selectedRow != -1) {
            // Retrieve the GradeID value from the selected row
            int gradeID = (Integer) tableGrades.getValueAt(selectedRow, 0);

            // Fetch current data for the selected grade
            String query = "SELECT * FROM tbl_grade WHERE GradeID = ?";
            try (Connection connection = getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                preparedStatement.setInt(1, gradeID);
                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    // Create a form to edit the grade's details
                    JTextField txtEnrollmentID = new JTextField(resultSet.getString("EnrollmentID"));
                    JTextField txtGrade = new JTextField(resultSet.getString("Grade"));
                    JDateChooser calenDateRecorded = new JDateChooser(resultSet.getDate("DateRecorded"));

                    JPanel panel = new JPanel(new GridLayout(4, 2));
                    panel.add(new JLabel("Enrollment ID:"));
                    panel.add(txtEnrollmentID);
                    panel.add(new JLabel("Grade:"));
                    panel.add(txtGrade);
                    panel.add(new JLabel("Date Recorded:"));
                    panel.add(calenDateRecorded);

                    int result = JOptionPane.showConfirmDialog(this, panel, "Edit Grade", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        // Update grade details
                        String updateQuery = "UPDATE tbl_grade SET EnrollmentID = ?, Grade = ?, DateRecorded = ? WHERE GradeID = ?";
                        try (PreparedStatement updateStatement = connection.prepareStatement(updateQuery)) {
                            updateStatement.setString(1, txtEnrollmentID.getText());
                            updateStatement.setString(2, txtGrade.getText());
                            updateStatement.setDate(3, new java.sql.Date(calenDateRecorded.getDate().getTime()));
                            updateStatement.setInt(4, gradeID);

                            int rowsAffected = updateStatement.executeUpdate();
                            if (rowsAffected > 0) {
                                JOptionPane.showMessageDialog(this, "Grade details updated successfully!");
                                refreshGradeTable();
                            } else {
                                JOptionPane.showMessageDialog(this, "Failed to update grade details. No rows affected.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "No data found for the selected grade.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "No grade selected.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deletes the selected grade record.
     */
    private void deleteSelectedGrade() {
        int selectedRow = tableGrades.getSelectedRow();
        if (selectedRow != -1) {
            // Get GradeID from the selected row
            int gradeID = (Integer) tableGrades.getValueAt(selectedRow, 0);

            // Confirm deletion
            int confirmed = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to delete this grade?",
                    "Delete Confirmation",
                    JOptionPane.YES_NO_OPTION);

            if (confirmed == JOptionPane.YES_OPTION) {
                // SQL query to delete the grade record
                String query = "DELETE FROM tbl_grade WHERE GradeID = ?";

                try (Connection connection = getConnection();
                     PreparedStatement preparedStatement = connection.prepareStatement(query)) {

                    // Set the GradeID parameter
                    preparedStatement.setInt(1, gradeID);

                    // Execute the update
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        // Notify the user of success
                        JOptionPane.showMessageDialog(this,
                                "Grade deleted successfully!");

                        // Refresh the table data
                        refreshGradeTable();
                    } else {
                        // Notify the user if no rows were affected
                        JOptionPane.showMessageDialog(this,
                                "Failed to delete grade. No rows affected.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException e) {
                    // Handle SQL exceptions
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(this,
                            "Database error: " + e.getMessage(),
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            // Notify the user if no row is selected
            JOptionPane.showMessageDialog(this,
                    "No grade selected.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Refreshes the table with the latest grade records.
     */
    private void refreshGradeTable() {
        String query = "SELECT GradeID, EnrollmentID, Grade, DateRecorded FROM tbl_grade";

        try (Connection connection = getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            tableGrades.setModel(buildTableModel(resultSet));

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Builds a table model from a ResultSet for displaying in JTable.
     *
     * @param resultSet The ResultSet from a database query.
     * @return A DefaultTableModel representing the ResultSet data.
     * @throws SQLException If an error occurs while processing the ResultSet.
     */
    private DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Get column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 1; i <= columnCount; i++) {
            columnNames[i - 1] = metaData.getColumnName(i);
        }

        // Populate data rows
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = resultSet.getObject(i);
            }
            model.addRow(row);
        }

        return model;
    }

    /**
     * Exports the table data to a CSV file.
     */
    private void exportTableData() {
        // Create a file chooser for saving the CSV file
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Save as CSV");

        // Show save dialog
        int userSelection = fileChooser.showSaveDialog(this);
        if (userSelection == JFileChooser.APPROVE_OPTION) {
            String filePath = fileChooser.getSelectedFile().getAbsolutePath();
            if (!filePath.endsWith(".csv")) {
                filePath += ".csv"; // Append .csv extension if not present
            }

            // Write table data to CSV file
            try (FileWriter fileWriter = new FileWriter(filePath)) {
                // Get column names
                DefaultTableModel model = (DefaultTableModel) tableGrades.getModel();
                for (int i = 0; i < model.getColumnCount(); i++) {
                    fileWriter.write(model.getColumnName(i) + (i < model.getColumnCount() - 1 ? "," : "\n"));
                }

                // Get row data
                for (int i = 0; i < model.getRowCount(); i++) {
                    for (int j = 0; j < model.getColumnCount(); j++) {
                        fileWriter.write(model.getValueAt(i, j) + (j < model.getColumnCount() - 1 ? "," : "\n"));
                    }
                }

                JOptionPane.showMessageDialog(this, "Data exported successfully!");
            } catch (IOException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error exporting data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
     * Retrieves the connection to the database.
     *
     * @return A Connection object to the database.
     * @throws SQLException If an error occurs while establishing the connection.
     */
    private Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/unilink_db";
        String user = "root";
        String password = "nics1108";
        return DriverManager.getConnection(url, user, password);
    }

    /**
     * Navigates back to the main menu.
     */
    private void backToMenu() {
        // Implement your back to menu logic here
        new dashboard().setVisible(true); // Assuming dashboard is another JFrame for the main menu
        this.dispose();
    }

    /**
     * Main method to launch the application.
     *
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new viewRecordsGrade().setVisible(true));
    }
}
